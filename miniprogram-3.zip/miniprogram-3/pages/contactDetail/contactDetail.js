Page({
  data: {
    name: '',
    phone: '',
    address: ''
  },

  onLoad(options) {
    // 获取传递的参数
    const { name, phone, address } = options;

    // 更新页面的数据
    this.setData({
      name,
      phone,
      address
    });
  },

  // 删除联系人
  deleteContact() {
    const that = this;
    wx.showModal({
      title: '确认删除',
      content: `是否删除联系人 ${that.data.name}？`,
      success(res) {
        if (res.confirm) {
          // 删除联系人（返回到上一个页面后，需要删除原联系人）
          const pages = getCurrentPages(); // 获取页面栈
          const prevPage = pages[pages.length - 2]; // 获取上一个页面
          const contacts = prevPage.data.contacts;  // 获取上一个页面的联系人列表

          // 找到并删除对应联系人
          const index = contacts.findIndex(contact => contact.name === that.data.name && contact.phone === that.data.phone);
          if (index !== -1) {
            contacts.splice(index, 1);
            prevPage.setData({ contacts }); // 更新联系人列表
          }

          wx.navigateBack();  // 返回到上一个页面
          wx.showToast({
            title: '删除成功',
            icon: 'success'
          });
        }
      }
    });
  }
});
