Page({
  data: {
    contacts: [] // 存储联系人数据 { name: '', phone: '', address: '', isStarred: false }
  },

  // 添加联系人
  addContact() {
    const that = this;
    wx.showModal({
      title: "请输入联系人姓名",
      editable: true,
      placeholderText: "联系人姓名",
      success(res) {
        if (res.confirm && res.content.trim()) {
          const name = res.content.trim();

          // 弹窗输入电话号码
          wx.showModal({
            title: `请输入 ${name} 的电话号码`,
            editable: true,
            placeholderText: "电话号码",
            success(resPhone) {
              if (resPhone.confirm && resPhone.content.trim()) {
                const phone = resPhone.content.trim();

                // 弹窗输入地址
                wx.showModal({
                  title: `请输入 ${name} 的地址`,
                  editable: true,
                  placeholderText: "地址",
                  success(resAddress) {
                    if (resAddress.confirm && resAddress.content.trim()) {
                      const address = resAddress.content.trim();

                      // 创建新联系人
                      const newContact = { 
                        name, 
                        phone, 
                        address, 
                        isStarred: false // 默认没有星标
                      };
                      const updatedContacts = [...that.data.contacts, newContact];
                      that.setData({ contacts: updatedContacts }); // 更新联系人列表
                      wx.showToast({
                        title: "添加成功",
                        icon: "success"
                      });
                    }
                  }
                });
              }
            }
          });
        }
      }
    });
  },

  // 跳转到联系人详情页面
  goToDetail(e) {
    const index = e.currentTarget.dataset.index;
    const contact = this.data.contacts[index];
    wx.navigateTo({
      url: `/pages/contactDetail/contactDetail?name=${contact.name}&phone=${contact.phone}&address=${contact.address}`,
    });
  },

  // 切换星标状态
  toggleStar(e) {
    const index = e.currentTarget.dataset.index;
    const updatedContacts = [...this.data.contacts];
    updatedContacts[index].isStarred = !updatedContacts[index].isStarred; // 切换 isStarred 状态
    this.setData({ contacts: updatedContacts });
  },
});
